require 'test_helper'

class SecretNumbersHelperTest < ActionView::TestCase
end
