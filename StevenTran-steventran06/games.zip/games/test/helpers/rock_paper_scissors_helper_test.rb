require 'test_helper'

class RockPaperScissorsHelperTest < ActionView::TestCase
end
