class GamesController < ApplicationController
  def index
  end
end
